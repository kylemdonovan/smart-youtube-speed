document.getElementById('myHeading').style.color = 'red'
